const profile = {
    name : "D13 Smart Watch",
    description : "D13 Smart Watch for boys/D20 T500/D13 smart watch strap/D13 smart watch band/D13 smart watch 2021/D13 smart watch charger/D13 watch/D13 bluetooth mobile",
    price : 3000,
    discount : "82%",
    discountedprice: 551,
    color : "Black",
    ratings: 914,
    answeredQuestions: 271,
    quantity: 1,
    return: "14 days Easy Return",
    warranty: "No Warranty"
}
console.log(profile)