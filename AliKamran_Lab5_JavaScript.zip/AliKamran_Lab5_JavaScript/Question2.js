let emergency = false;
let density = "High";

if (emergency === true) {
    console.log("Light turns green immediately for 90 seconds.");
} 
else if (density === "High") {
    console.log("Green light stays on for 60 seconds.");
} 
else if (density === "Medium") {
    console.log("Green light stays on for 40 seconds.");
} 
else if (density === "Low") {
    console.log("Green light stays on for 20 seconds.");
} 
else {
    console.log("Invalid input.");
}
