function getComputerChoice() {
    return "scissors";
  }
    function determineWinner(player, computer) {
    if (player === computer) {
      return "tie";
    }
    if (
      (player === "rock" && computer === "scissors") ||
      (player === "scissors" && computer === "paper") ||
      (player === "paper" && computer === "rock")
    ) {
      return "player";
    }
    return "computer";
  }
    function playRound() {
    let player = "rock";
    let computer = getComputerChoice();
    let winner = determineWinner(player, computer);
  
    console.log("Player:", player, " Computer:", computer);
    console.log("Round winner:", winner);
  
    return winner;
  }
    function playMatch() {
    let playerScore = 0;
    let computerScore = 0;
  
    while (playerScore < 2 && computerScore < 2) {
      let result = playRound();
  
      if (result === "player") {
        playerScore = playerScore + 1;
      } else if (result === "computer") {
        computerScore = computerScore + 1;
      }
  
      console.log("Player Score:", playerScore, "Computer Score:", computerScore);
    }
    if (playerScore === 2) {
      console.log("Player won the match!");
    } else {
      console.log("Computer won the match!");
    }
  }
    playMatch();
  