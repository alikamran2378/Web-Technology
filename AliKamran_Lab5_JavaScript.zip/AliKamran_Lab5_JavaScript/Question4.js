let marks =[80,90,75, 68, 87.41,59,88, 77, 66];

for (let i = 0; i < marks.length; i++) {
    console.log("Marks:", i);
  }
let total = 0;
let highest = marks[0];
let lowest = marks[0];
let passedCount = 0;
let failedCount = 0;

for (let i = 0; i < marks.length; i++) {
  total = total + marks[i];

  if (marks[i] > highest) {
    highest = marks[i];
  }
  if (marks[i] < lowest) {
    lowest = marks[i];
  }

  if (marks[i] >= 50) {
    passedCount = passedCount + 1;
  } else {
    failedCount = failedCount + 1;
  }
}
let average = total / marks.length;

console.log("Total Marks:", total);
console.log("Average Marks:", average);
console.log("Highest Marks:", highest);
console.log("Lowest Marks:", lowest);
console.log("Passed Students:", passedCount);
console.log("Failed Students:", failedCount);

let grades = marks.map(function (m) {
  if (m >= 80) return "A";
  if (m >= 60) return "B";
  if (m >= 50) return "C";
  return "Fail";
});
console.log("Grades:", grades);

let passedStudents = marks.filter(function (m) {
  return m >= 50;
});
console.log("Passed Marks List:", passedStudents);

let ascending = [...marks].sort(function (a, b) {
  return a - b;
});
let descending = [...marks].sort(function (a, b) {
  return b - a;
});
console.log("Sorted Marks (Ascending):", ascending);
console.log("Sorted Marks (Descending):", descending);

let uniqueMarks = [];
for (let i = 0; i < marks.length; i++) {
  if (!uniqueMarks.includes(marks[i])) {
    uniqueMarks.push(marks[i]);
  }
}
console.log("Unique Marks:", uniqueMarks);

let searchMark = 89;
console.log("Is", searchMark, "present?:", marks.includes(searchMark));
